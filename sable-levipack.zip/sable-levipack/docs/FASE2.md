# Fase 2 - ligar a física ao jogo

Dados levantados dos arquivos enviados:
- O `libminecraftpe.so` arm64 está em `split_game_assets.apk > assets/bundled_game/game.apk >
  lib/arm64-v8a/` (328 MB, stripped, ~90 mil símbolos dinâmicos).
- A API do preloader (`libpreloader.so`) expõe `pl::memory::hook`, `resolveSignature(s)`,
  `resolveVtableFunction`, `pl::patch::*` e `pl::modmenu::*`.

Para sub-estruturas do Sable no Bedrock, os pontos a hookar são (assinaturas ainda a achar):
1. Tick do `Level` (avançar `sable::World`).
2. Consulta de blocos/colisão do `BlockSource` (implementar `VoxelQuery`).
3. Colisão e movimento de `Actor`/`Player` sobre a estrutura.
4. Render: estrutura como entidade/BlockActor com transform (posição + quaternion).

Cada assinatura exige análise do binário; é o trabalho da próxima etapa.
