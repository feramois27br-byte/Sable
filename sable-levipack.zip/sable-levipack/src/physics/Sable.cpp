#include "Sable.hpp"

#include <algorithm>

namespace sable {

namespace {
Vec3 mulComp(Vec3 a, Vec3 b) { return {a.x * b.x, a.y * b.y, a.z * b.z}; }
// Inversa da inércia no mundo aplicada a v: R * (Iinv_local * (R^T * v))
Vec3 invInertiaWorld(const Body &b, Vec3 v) {
  Vec3 local = rotate(conj(b.rotation), v);
  return rotate(b.rotation, mulComp(b.invInertiaLocal, local));
}
double effMass(const Body &b, Vec3 r, Vec3 d) {
  Vec3 rd = cross(r, d);
  Vec3 t = cross(invInertiaWorld(b, rd), r);
  return b.invMass + dot(d, t);
}
void applyImpulse(Body &b, Vec3 r, Vec3 p) {
  b.linearVelocity = b.linearVelocity + p * b.invMass;
  b.angularVelocity = b.angularVelocity + invInertiaWorld(b, cross(r, p));
}
} // namespace

struct World::Contact {
  Vec3 r, n, t1, t2;
  double depth = 0, kN = 1, kT1 = 1, kT2 = 1;
  double jn = 0, jt1 = 0, jt2 = 0;
};

int World::addBody(const BodyDesc &d) {
  Body b;
  b.alive = true;
  b.position = d.position;
  b.rotation = normalize(d.rotation);
  b.halfExtents = d.halfExtents;
  b.mass = std::max(d.mass, 1e-6);
  b.invMass = 1.0 / b.mass;
  b.friction = d.friction;
  double w = 2 * d.halfExtents.x, h = 2 * d.halfExtents.y, l = 2 * d.halfExtents.z;
  double m = b.mass;
  b.invInertiaLocal = {12.0 / (m * (h * h + l * l)), 12.0 / (m * (w * w + l * l)),
                       12.0 / (m * (w * w + h * h))};
  for (auto &e : bodies_) {
    if (!e.alive) {
      int id = e.id;
      e = b;
      e.id = id;
      return id;
    }
  }
  b.id = static_cast<int>(bodies_.size());
  bodies_.push_back(b);
  return b.id;
}

void World::removeBody(int id) {
  if (id >= 0 && id < static_cast<int>(bodies_.size())) bodies_[id].alive = false;
}
Body *World::body(int id) {
  if (id < 0 || id >= static_cast<int>(bodies_.size()) || !bodies_[id].alive) return nullptr;
  return &bodies_[id];
}
const Body *World::body(int id) const {
  if (id < 0 || id >= static_cast<int>(bodies_.size()) || !bodies_[id].alive) return nullptr;
  return &bodies_[id];
}
size_t World::bodyCount() const {
  size_t n = 0;
  for (auto &b : bodies_) n += b.alive ? 1 : 0;
  return n;
}

void World::step(double dt) {
  int sub = std::max(1, settings.substeps);
  double h = dt / sub;
  for (int s = 0; s < sub; ++s)
    for (auto &b : bodies_)
      if (b.alive) stepBody(b, h);
}

void World::stepBody(Body &b, double h) {
  const Settings &S = settings;
  b.linearVelocity = b.linearVelocity + S.gravity * h;
  b.linearVelocity = b.linearVelocity * (1.0 - S.linearDamping * h);
  b.angularVelocity = b.angularVelocity * (1.0 - S.angularDamping * h);

  std::vector<Contact> contacts;
  if (voxels_) {
    static const int dirs[6][3] = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    for (int sx = -1; sx <= 1; ++sx)
      for (int sy = -1; sy <= 1; ++sy)
        for (int sz = -1; sz <= 1; ++sz) {
          if (!sx && !sy && !sz) continue;
          Vec3 local{sx * b.halfExtents.x, sy * b.halfExtents.y, sz * b.halfExtents.z};
          Vec3 r = rotate(b.rotation, local);
          Vec3 p = b.position + r;
          int ix = (int)std::floor(p.x), iy = (int)std::floor(p.y), iz = (int)std::floor(p.z);
          if (!voxels_->isSolid(ix, iy, iz)) continue;
          double best = 1e30;
          int bi = -1;
          for (int d = 0; d < 6; ++d) {
            if (voxels_->isSolid(ix + dirs[d][0], iy + dirs[d][1], iz + dirs[d][2])) continue;
            double depth = 0;
            switch (d) {
            case 0: depth = (ix + 1) - p.x; break;
            case 1: depth = p.x - ix; break;
            case 2: depth = (iy + 1) - p.y; break;
            case 3: depth = p.y - iy; break;
            case 4: depth = (iz + 1) - p.z; break;
            default: depth = p.z - iz; break;
            }
            if (depth < best) { best = depth; bi = d; }
          }
          if (bi < 0) continue; // enterrado: sem face livre
          Contact c;
          c.r = r;
          c.n = {(double)dirs[bi][0], (double)dirs[bi][1], (double)dirs[bi][2]};
          c.depth = best;
          Vec3 a = std::fabs(c.n.y) > 0.5 ? Vec3{1, 0, 0} : Vec3{0, 1, 0};
          Vec3 t1 = cross(c.n, a);
          t1 = t1 * (1.0 / length(t1));
          c.t1 = t1;
          c.t2 = cross(c.n, t1);
          c.kN = effMass(b, r, c.n);
          c.kT1 = effMass(b, r, c.t1);
          c.kT2 = effMass(b, r, c.t2);
          contacts.push_back(c);
        }
  }

  for (int it = 0; it < S.solverIterations; ++it) {
    for (auto &c : contacts) {
      Vec3 v = b.linearVelocity + cross(b.angularVelocity, c.r);
      double vn = dot(v, c.n);
      double bias = std::min(S.maxCorrectionSpeed, S.baumgarte / h * std::max(c.depth - S.slop, 0.0));
      double j = (bias - vn) / c.kN;
      double acc = std::max(c.jn + j, 0.0);
      j = acc - c.jn;
      c.jn = acc;
      applyImpulse(b, c.r, c.n * j);

      double maxF = b.friction * c.jn;
      v = b.linearVelocity + cross(b.angularVelocity, c.r);
      double j1 = -dot(v, c.t1) / c.kT1;
      double a1 = std::clamp(c.jt1 + j1, -maxF, maxF);
      j1 = a1 - c.jt1; c.jt1 = a1;
      applyImpulse(b, c.r, c.t1 * j1);
      v = b.linearVelocity + cross(b.angularVelocity, c.r);
      double j2 = -dot(v, c.t2) / c.kT2;
      double a2 = std::clamp(c.jt2 + j2, -maxF, maxF);
      j2 = a2 - c.jt2; c.jt2 = a2;
      applyImpulse(b, c.r, c.t2 * j2);
    }
  }

  b.position = b.position + b.linearVelocity * h;
  Quat dq = mul(Quat{0, b.angularVelocity.x, b.angularVelocity.y, b.angularVelocity.z}, b.rotation);
  b.rotation = normalize({b.rotation.w + 0.5 * h * dq.w, b.rotation.x + 0.5 * h * dq.x,
                          b.rotation.y + 0.5 * h * dq.y, b.rotation.z + 0.5 * h * dq.z});
}

} // namespace sable
