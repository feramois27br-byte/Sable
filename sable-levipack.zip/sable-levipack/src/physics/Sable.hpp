// Núcleo de física do port do Sable (fase 1).
// Corpo rígido (caixa) contra mundo de voxels estático. Unidades: 1 bloco = 1 m.
// Sem dependências de Android/Minecraft: compila e testa em qualquer PC.
#pragma once
#include <cmath>
#include <cstddef>
#include <vector>

namespace sable {

struct Vec3 {
  double x = 0, y = 0, z = 0;
};
inline Vec3 operator+(Vec3 a, Vec3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
inline Vec3 operator-(Vec3 a, Vec3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
inline Vec3 operator*(Vec3 a, double s) { return {a.x * s, a.y * s, a.z * s}; }
inline double dot(Vec3 a, Vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline Vec3 cross(Vec3 a, Vec3 b) {
  return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
}
inline double length(Vec3 a) { return std::sqrt(dot(a, a)); }

struct Quat {
  double w = 1, x = 0, y = 0, z = 0;
};
inline Quat mul(Quat a, Quat b) {
  return {a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
          a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
          a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
          a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w};
}
inline Quat conj(Quat q) { return {q.w, -q.x, -q.y, -q.z}; }
inline Quat normalize(Quat q) {
  double n = std::sqrt(q.w * q.w + q.x * q.x + q.y * q.y + q.z * q.z);
  if (n < 1e-12) return {};
  return {q.w / n, q.x / n, q.y / n, q.z / n};
}
inline Vec3 rotate(Quat q, Vec3 v) {
  Quat p{0, v.x, v.y, v.z};
  Quat r = mul(mul(q, p), conj(q));
  return {r.x, r.y, r.z};
}
inline Quat fromAxisAngle(Vec3 axis, double angle) {
  double l = length(axis);
  if (l < 1e-12) return {};
  double s = std::sin(angle * 0.5) / l;
  return normalize({std::cos(angle * 0.5), axis.x * s, axis.y * s, axis.z * s});
}

// Ponto de integração com o jogo: no Bedrock isto será ligado ao BlockSource.
class VoxelQuery {
public:
  virtual ~VoxelQuery() = default;
  virtual bool isSolid(int x, int y, int z) const = 0;
};

struct BodyDesc {
  Vec3 position;
  Quat rotation;
  Vec3 halfExtents{0.5, 0.5, 0.5};
  double mass = 1.0;
  double friction = 0.6;
};

struct Body {
  int id = -1;
  bool alive = false;
  Vec3 position;
  Quat rotation;
  Vec3 linearVelocity;
  Vec3 angularVelocity;
  Vec3 halfExtents{0.5, 0.5, 0.5};
  double mass = 1.0;
  double invMass = 1.0;
  Vec3 invInertiaLocal;
  double friction = 0.6;
};

struct Settings {
  Vec3 gravity{0, -9.81, 0};
  int substeps = 4;
  int solverIterations = 8;
  double linearDamping = 0.01;
  double angularDamping = 0.05;
  double baumgarte = 0.2;
  double slop = 0.005;
  double maxCorrectionSpeed = 4.0;
};

class World {
public:
  explicit World(const VoxelQuery *voxels) : voxels_(voxels) {}
  Settings settings;

  int addBody(const BodyDesc &d);
  void removeBody(int id);
  Body *body(int id);
  const Body *body(int id) const;
  size_t bodyCount() const;
  void step(double dt);

private:
  struct Contact;
  void stepBody(Body &b, double h);
  const VoxelQuery *voxels_;
  std::vector<Body> bodies_;
};

} // namespace sable
