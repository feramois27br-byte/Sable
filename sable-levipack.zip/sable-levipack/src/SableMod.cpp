// Sable (port nativo) - fase 1: carrega no LeviLauncher, registra o módulo no
// Mod Menu e roda um autoteste do núcleo de física, com resultado no logcat (tag "Sable").
// A API pl:: segue o exemplo oficial examples/mod-menu-api do LeviLauncher-Android.
#include <android/log.h>

#include <cstdlib>
#include <string>
#include <string_view>

#include <pl/Mod.hpp>
#include <pl/ModMenu.hpp>

#include "physics/Sable.hpp"

namespace {

constexpr const char *kTag = "Sable";
constexpr const char *kModule = "sable.physics";

// Mundo plano provisório. Na fase 2 isto passa a consultar o BlockSource do jogo.
struct FlatFloor : sable::VoxelQuery {
  bool isSolid(int, int y, int) const override { return y < 0 && y >= -3; }
};

FlatFloor g_floor;
sable::World g_world(&g_floor);
bool g_enabled = true;

bool selfTest() {
  sable::World w(&g_floor);
  w.settings = g_world.settings;
  sable::BodyDesc d;
  d.position = {0.3, 10, 0.2};
  d.rotation = sable::fromAxisAngle({1, 0, 1}, 0.5);
  int id = w.addBody(d);
  for (int i = 0; i < 200; ++i)
    w.step(0.05);
  const sable::Body *b = w.body(id);
  bool ok = b && b->position.y > 0.45 && b->position.y < 0.52 &&
            sable::length(b->linearVelocity) < 0.05;
  __android_log_print(ANDROID_LOG_INFO, kTag,
                      "autoteste da fisica: %s (y=%.4f, |v|=%.4f)", ok ? "OK" : "FALHOU",
                      b ? b->position.y : -1.0, b ? sable::length(b->linearVelocity) : -1.0);
  return ok;
}

void onModuleToggle(std::string_view moduleId, bool enabled) {
  if (moduleId == kModule)
    g_enabled = enabled;
  __android_log_print(ANDROID_LOG_INFO, kTag, "modulo %.*s = %s",
                      static_cast<int>(moduleId.size()), moduleId.data(),
                      enabled ? "ligado" : "desligado");
}

void onConfigChanged(std::string_view moduleId, std::string_view key, std::string_view value) {
  if (moduleId != kModule)
    return;
  const std::string v(value);
  sable::Settings &s = g_world.settings;
  if (key == "gravity")
    s.gravity = {0, -std::strtod(v.c_str(), nullptr), 0};
  else if (key == "substeps")
    s.substeps = std::atoi(v.c_str());
  else if (key == "iterations")
    s.solverIterations = std::atoi(v.c_str());
  __android_log_print(ANDROID_LOG_INFO, kTag, "config %.*s = %s", static_cast<int>(key.size()),
                      key.data(), v.c_str());
}

class SableMod {
public:
  bool load(pl::mod::ModContext &context) {
    (void)context;
    __android_log_print(ANDROID_LOG_INFO, kTag, "load (port do Sable 0.1.0)");
    return pl::modmenu::ModuleBuilder(kModule, "Sable Physics")
        .description("Fisica de estruturas moveis (fase 1: nucleo + menu).")
        .defaultEnabled(true)
        .onToggle(onModuleToggle)
        .config("gravity", "Gravidade (m/s2)", pl::modmenu::ConfigType::SliderFloat, "9.81", "0.5",
                "20.0")
        .config("substeps", "Subpassos", pl::modmenu::ConfigType::SliderInt, "4", "1", "8")
        .config("iterations", "Iteracoes do solver", pl::modmenu::ConfigType::SliderInt, "8", "2",
                "16")
        .onConfigChanged(onConfigChanged)
        .registerModule();
  }

  bool enable(pl::mod::ModContext &context) {
    (void)context;
    __android_log_print(ANDROID_LOG_INFO, kTag, "enable");
    selfTest();
    return true;
  }

  bool disable(pl::mod::ModContext &context) {
    (void)context;
    __android_log_print(ANDROID_LOG_INFO, kTag, "disable");
    pl::modmenu::unregisterModule(kModule);
    return true;
  }

  bool unload(pl::mod::ModContext &context) {
    (void)context;
    __android_log_print(ANDROID_LOG_INFO, kTag, "unload");
    return true;
  }
};

SableMod g_mod;

} // namespace

PL_REGISTER_MOD(SableMod, g_mod)
