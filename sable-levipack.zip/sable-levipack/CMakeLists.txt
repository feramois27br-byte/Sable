cmake_minimum_required(VERSION 3.22)
project(sable_levipack LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

include(FetchContent)

# Checkout de https://github.com/LiteLDev/preloader-android (headers pl/)
set(PRELOADER_ANDROID_ROOT "${CMAKE_CURRENT_LIST_DIR}/preloader-android"
    CACHE PATH "Caminho do checkout do LiteLDev/preloader-android")
if(NOT EXISTS "${PRELOADER_ANDROID_ROOT}/include/pl/ModMenu.hpp")
  message(FATAL_ERROR "Faltou ${PRELOADER_ANDROID_ROOT}/include/pl/ModMenu.hpp")
endif()

option(SABLE_LINK_PRELOADER "Compilar e linkar o alvo preloader local" ON)
if(SABLE_LINK_PRELOADER AND NOT TARGET preloader)
  add_subdirectory("${PRELOADER_ANDROID_ROOT}" "${CMAKE_BINARY_DIR}/_preloader_android")
endif()

if(NOT TARGET fmt::fmt)
  FetchContent_Declare(fmt GIT_REPOSITORY https://github.com/fmtlib/fmt.git GIT_TAG 11.2.0)
  set(FMT_DOC OFF CACHE BOOL "" FORCE)
  set(FMT_TEST OFF CACHE BOOL "" FORCE)
  set(FMT_INSTALL OFF CACHE BOOL "" FORCE)
  FetchContent_MakeAvailable(fmt)
endif()

if(ANDROID_ABI)
  set(SABLE_ABI "${ANDROID_ABI}")
else()
  set(SABLE_ABI "host")
endif()
set(CMAKE_LIBRARY_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/out/${SABLE_ABI}")

find_library(SABLE_LOG_LIB log)

add_library(sable SHARED src/SableMod.cpp src/physics/Sable.cpp)
target_include_directories(sable PRIVATE src "${PRELOADER_ANDROID_ROOT}/include")
target_compile_options(sable PRIVATE
  $<$<COMPILE_LANG_AND_ID:CXX,Clang,GNU>:-Wall -Wextra -fvisibility=hidden -fvisibility-inlines-hidden>)
if(SABLE_LOG_LIB)
  target_link_libraries(sable PRIVATE "${SABLE_LOG_LIB}")
endif()
target_link_libraries(sable PRIVATE fmt::fmt)
if(TARGET preloader)
  target_link_libraries(sable PRIVATE preloader)
else()
  target_link_options(sable PRIVATE -Wl,--unresolved-symbols=ignore-all)
endif()
