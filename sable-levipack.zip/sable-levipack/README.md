# Sable (port nativo) para LeviLauncher - fase 1

Este projeto gera um `.levipack` (`preload-native`, arm64-v8a) do mod **Sable** para o
Minecraft Bedrock 26.52 no LeviLauncher, sem precisar de PC: a compilação roda no
GitHub Actions.

## O que a fase 1 faz
- Carrega no LeviLauncher e registra o módulo **Sable Physics** no Mod Menu
  (gravidade, subpassos e iterações do solver).
- Inclui o núcleo de física (`src/physics`): corpos rígidos em caixa contra um mundo de
  voxels, com atrito. Testado no PC: assenta em faces, não atravessa o chão, para por atrito.
- No `enable` roda um autoteste e escreve no logcat (tag `Sable`):
  `autoteste da fisica: OK`.

**Ainda não altera o jogo.** Estruturas móveis, colisão com jogador e render dependem da
fase 2 (hooks no `libminecraftpe.so`). Veja `docs/FASE2.md`.

## Como compilar pelo celular
1. Crie um repositório no GitHub (app ou site).
2. Em **Add file > Create new file**, digite o nome `.github/workflows/build.yml` e cole o
   conteúdo do arquivo `build.yml` que veio junto.
3. Em **Add file > Upload files**, envie o `sable-levipack.zip` (sem extrair) na raiz.
4. Aba **Actions > Build Sable levipack > Run workflow**.
5. Ao terminar, baixe o artefato `sable-levipack` (contém `sable.levipack`) e importe no
   LeviLauncher.

Se o build falhar, copie o trecho final do log do passo que ficou vermelho.

## Licença
O Sable original usa a PolyForm Shield 1.0.0. Uso pessoal é ok; antes de publicar ou
distribuir o port, confira a licença ou peça permissão ao autor (RyanHCode).
