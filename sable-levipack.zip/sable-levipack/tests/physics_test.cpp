#include "../src/physics/Sable.hpp"
#include <algorithm>
#include <cstdio>
#include <cstdlib>

using namespace sable;

struct Floor : VoxelQuery {
  bool isSolid(int, int y, int) const override { return y < 0 && y >= -3; }
};

static int fails = 0;
#define CHECK(cond, ...) do { if (!(cond)) { ++fails; std::printf("FALHOU: " __VA_ARGS__); std::printf("\n"); } } while (0)

static double alignY(const Body &b) {
  double a = std::fabs(rotate(b.rotation, {1, 0, 0}).y);
  double c = std::fabs(rotate(b.rotation, {0, 1, 0}).y);
  double d = std::fabs(rotate(b.rotation, {0, 0, 1}).y);
  return std::max(a, std::max(c, d));
}

int main() {
  Floor floor;
  {
    World w(&floor);
    BodyDesc d; d.position = {0.3, 10, 0.2}; d.rotation = fromAxisAngle({1, 0, 1}, 0.5);
    int id = w.addBody(d);
    for (int i = 0; i < 200; ++i) w.step(0.05);
    const Body *b = w.body(id);
    std::printf("queda inclinada: y=%.4f |v|=%.4f |w|=%.4f alinhamento=%.4f\n", b->position.y,
                length(b->linearVelocity), length(b->angularVelocity), alignY(*b));
    CHECK(b->position.y > 0.45 && b->position.y < 0.52, "altura de repouso fora de [0.45,0.52]");
    CHECK(length(b->linearVelocity) < 0.05, "ainda se movendo");
    CHECK(length(b->angularVelocity) < 0.05, "ainda girando");
    CHECK(alignY(*b) > 0.99, "nao assentou em uma face");
  }
  {
    World w(&floor);
    BodyDesc d; d.position = {0, 0.5, 0};
    int id = w.addBody(d);
    w.body(id)->linearVelocity = {5, 0, 0};
    for (int i = 0; i < 200; ++i) w.step(0.05);
    const Body *b = w.body(id);
    std::printf("deslize: x=%.3f (ideal ~2.12) |v|=%.4f y=%.4f\n", b->position.x, length(b->linearVelocity), b->position.y);
    CHECK(length(b->linearVelocity) < 0.05, "deslize nao parou");
    CHECK(b->position.x > 1.5 && b->position.x < 2.8, "distancia de deslize fora do esperado");
  }
  {
    World w(&floor);
    BodyDesc d; d.position = {0, 30, 0};
    int id = w.addBody(d);
    for (int i = 0; i < 200; ++i) w.step(0.05);
    const Body *b = w.body(id);
    std::printf("queda de 30m: y=%.4f |v|=%.4f\n", b->position.y, length(b->linearVelocity));
    CHECK(b->position.y > 0.4, "atravessou o chao");
  }
  {
    World w(&floor);
    BodyDesc d; d.position = {0, 5, 0}; d.halfExtents = {1.0, 0.5, 0.5}; d.mass = 20;
    d.rotation = fromAxisAngle({0, 0, 1}, 1.0);
    int id = w.addBody(d);
    for (int i = 0; i < 300; ++i) w.step(0.05);
    const Body *b = w.body(id);
    std::printf("viga 2x1x1: y=%.4f |v|=%.4f |w|=%.4f\n", b->position.y, length(b->linearVelocity), length(b->angularVelocity));
    CHECK(length(b->linearVelocity) < 0.05 && length(b->angularVelocity) < 0.05, "viga nao repousou");
  }
  std::printf(fails ? "\n%d teste(s) falharam\n" : "\nTodos os testes passaram\n", fails);
  return fails ? 1 : 0;
}
